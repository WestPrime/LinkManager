﻿namespace LinkManager
{
    public class ProjectLink
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public string FoundPath { get; set; }
        public string Action { get; set; }
    }
}
